'use client'

import { useEffect, useState, useCallback } from 'react'
import { createClient } from '@/utils/supabase/client'

export function useWalletBalance() {
  const [balance, setBalance] = useState(0)
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState<any>(null)
  const supabase = createClient()

  // Fetch wallet once on mount
  const fetchWallet = useCallback(async () => {
    try {
      const { data: { user: currentUser } } = await supabase.auth.getUser()
      
      if (!currentUser) {
        setLoading(false)
        return
      }

      setUser(currentUser)

      // Get current balance
      const { data: wallet, error } = await supabase
        .from('wallets')
        .select('balance')
        .eq('user_id', currentUser.id)
        .single()

      if (error) {
        console.error('Wallet fetch error:', error)
        setBalance(0)
      } else {
        console.log('✅ Wallet fetched:', wallet?.balance)
        setBalance(wallet?.balance || 0)
        localStorage.setItem('hub90_wallet_balance', (wallet?.balance || 0).toString())
      }
    } catch (err) {
      console.error('Error fetching wallet:', err)
    } finally {
      setLoading(false)
    }
  }, [supabase])

  // Initial fetch
  useEffect(() => {
    fetchWallet()
  }, [fetchWallet])

  // Subscribe to real-time wallet updates
  useEffect(() => {
    if (!user?.id) return

    console.log('🔔 Subscribing to wallet changes for:', user.id)

    const subscription = supabase
      .channel('wallet-updates')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'wallets',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('💰 Real-time wallet update:', payload.new)
          const newBalance = payload.new?.balance || 0
          setBalance(newBalance)
          localStorage.setItem('hub90_wallet_balance', newBalance.toString())
        }
      )
      .subscribe()

    return () => {
      console.log('🔕 Unsubscribing from wallet updates')
      supabase.removeChannel(subscription)
    }
  }, [user?.id, supabase])

  // Manual refresh function
  const refreshWallet = useCallback(async () => {
    console.log('🔄 Manually refreshing wallet...')
    await fetchWallet()
  }, [fetchWallet])

  // Update balance locally (instant feedback) then sync to DB
  const updateBalanceOptimistic = useCallback(async (newBalance: number) => {
    console.log('⚡ Optimistic update:', newBalance)
    setBalance(newBalance)
    localStorage.setItem('hub90_wallet_balance', newBalance.toString())
  }, [])

  return {
    balance,
    loading,
    user,
    refreshWallet,
    updateBalanceOptimistic
  }
}