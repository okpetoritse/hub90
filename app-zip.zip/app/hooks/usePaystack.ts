'use client'

import { useCallback } from 'react'
import { createClient } from '@/utils/supabase/client'

declare global {
  interface Window {
    PaystackPop: any
  }
}

export function usePaystack() {
  const supabase = createClient()

  const fundWallet = useCallback(async (amount: number, email: string) => {
    return new Promise<{success: boolean, newBalance: number, reference: string}>((resolve, reject) => {
      console.log('🎬 Starting Paystack flow...')
      
      // Load Paystack if not loaded
      if (!window.PaystackPop) {
        console.log('📥 Loading Paystack script...')
        const script = document.createElement('script')
        script.src = 'https://js.paystack.co/v1/inline.js'
        script.async = true
        
        script.onload = () => {
          console.log('✅ Paystack script loaded')
          setTimeout(() => openPaystack(), 300)
        }
        
        script.onerror = () => {
          console.error('❌ Failed to load Paystack')
          reject(new Error('Failed to load Paystack'))
        }
        
        document.head.appendChild(script)
      } else {
        console.log('✅ Paystack already loaded')
        openPaystack()
      }

      const openPaystack = () => {
        try {
          console.log('🎯 Opening Paystack iframe...')
          
          const handler = window.PaystackPop.setup({
            key: process.env.NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY,
            email: email,
            amount: amount * 100, // Convert to kobo
            ref: 'ref-' + Math.floor(Math.random() * 1000000000),
            currency: 'NGN',
            
            onClose: () => {
              console.log('⏹️ Payment modal closed by user')
              reject(new Error('Payment cancelled'))
            },
            
            onSuccess: async (response: any) => {
              console.log('✅ PAYSTACK PAYMENT SUCCESS!')
              console.log('📋 Reference:', response.reference)
              console.log('💳 Status:', response.status)
              
              try {
                // Get user
                const { data: { user } } = await supabase.auth.getUser()
                if (!user) {
                  console.error('❌ User not found')
                  throw new Error('User not authenticated')
                }

                console.log('👤 User ID:', user.id)
                console.log('💰 Adding: ₦' + amount)

                // Get current balance
                console.log('🔍 Fetching current balance...')
                const { data: wallet, error: fetchError } = await supabase
                  .from('wallets')
                  .select('balance')
                  .eq('user_id', user.id)
                  .single()

                if (fetchError) {
                  console.error('❌ Fetch error:', fetchError)
                  
                  // Try to create wallet if it doesn't exist
                  if (fetchError.code === 'PGRST116') {
                    console.log('📝 Wallet not found, creating...')
                    const { error: insertError } = await supabase
                      .from('wallets')
                      .insert({
                        user_id: user.id,
                        balance: amount,
                        currency: 'NGN'
                      })

                    if (insertError) {
                      console.error('❌ Insert error:', insertError)
                      throw insertError
                    }

                    console.log('✅ Wallet created')
                    localStorage.setItem('hub90_wallet_balance', amount.toString())
                    
                    resolve({
                      success: true,
                      newBalance: amount,
                      reference: response.reference
                    })
                    return
                  }
                  
                  throw fetchError
                }

                const currentBalance = wallet?.balance || 0
                const newBalance = currentBalance + amount

                console.log('💰 Current: ₦' + currentBalance)
                console.log('➕ Adding: ₦' + amount)
                console.log('📊 New: ₦' + newBalance)

                // Update balance in DB - CRITICAL STEP
                console.log('🔄 Updating wallet in database...')
                const { data: updated, error: updateError } = await supabase
                  .from('wallets')
                  .update({ 
                    balance: newBalance,
                    updated_at: new Date().toISOString()
                  })
                  .eq('user_id', user.id)
                  .select()

                if (updateError) {
                  console.error('❌ Update error:', updateError)
                  throw updateError
                }

                console.log('✅ Wallet updated in database:', updated)

                // Update localStorage
                localStorage.setItem('hub90_wallet_balance', newBalance.toString())
                console.log('💾 localStorage updated:', newBalance)

                // SUCCESS! Resolve the promise
                console.log('🎉 PAYMENT COMPLETE - Resolving promise')
                resolve({
                  success: true,
                  newBalance: newBalance,
                  reference: response.reference
                })

              } catch (error) {
                console.error('❌ Error in onSuccess handler:', error)
                reject(error)
              }
            }
          })

          handler.openIframe()
        } catch (error) {
          console.error('❌ Error opening Paystack:', error)
          reject(error)
        }
      }
    })
  }, [supabase])

  return { fundWallet }
}