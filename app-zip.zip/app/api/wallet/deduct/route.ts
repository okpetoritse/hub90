import { createClient } from '@/utils/supabase/server'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const { userId, itemType, cost } = await request.json()

    if (!userId || !itemType || !cost) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Use service role to bypass RLS
    const supabase = await createClient()

    // Step 1: Get current wallet balance
    const { data: wallet, error: fetchError } = await supabase
      .from('wallets')
      .select('balance')
      .eq('user_id', userId)
      .single()

    if (fetchError) {
      console.error('Fetch wallet error:', fetchError)
      return NextResponse.json(
        { error: 'Wallet not found. Please fund your wallet first.' },
        { status: 404 }
      )
    }

    const currentBalance = wallet?.balance || 0

    // Step 2: Check if user has enough balance
    if (currentBalance < cost) {
      return NextResponse.json(
        { error: `Insufficient balance. You have ₦${currentBalance}, but need ₦${cost}` },
        { status: 402 }
      )
    }

    // Step 3: Deduct from wallet
    const newBalance = currentBalance - cost
    const { error: updateError } = await supabase
      .from('wallets')
      .update({
        balance: newBalance,
        updated_at: new Date().toISOString()
      })
      .eq('user_id', userId)

    if (updateError) {
      console.error('Update wallet error:', updateError)
      return NextResponse.json(
        { error: 'Failed to process payment' },
        { status: 500 }
      )
    }

    return NextResponse.json({
      success: true,
      newBalance,
      message: `${itemType} activated! Balance: ₦${newBalance}`
    })

  } catch (error) {
    console.error('Deduct error:', error)
    return NextResponse.json(
      { error: 'Server error' },
      { status: 500 }
    )
  }
}